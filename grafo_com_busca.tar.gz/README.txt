Código desenvolvido pelo professor Thiago Pardo para a disciplina de Estruturas de Dados em 2020, ICMC USP.
